<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Cal Henderson

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '# Segment Tracker for MODX

This package contains options for tracking MODX user interactions in Segment. To signup for Segment visit https://segment.com/. 

This package assumes you have the Segment javascript tracking code enabled on the frontend of your site. 

## Snippets

### SegmentTrack

Add this snippet to a page or call via runSnippet to add segment tracking to interactions.
 
#### Properties:
    
| Property | Description |
| ----------- | ----------- |
| event (string) | A specified event to track (required) | 
| properties (mixed) | Track additional field value pairs either as a passed array array(\'property1\'=>\'value1\'), a comma-separated string `property1==value1`, or json `{"property1":"value1"}`. | 
| identity (mixed) | Add identity field value pairs either as a passed array array(\'id\'=>\'modx_1\',\'name\'=>\'Full Name\'), a comma-separated string `id==modx_1,name==Full Name`, or json `{"id":"modx_1","name":"Full Name"}`. | 
### Segment.FormIt.Hook
 
  Add this hook to a FormIt call to track interactions
 
#### Properties:

| Property | Description |
| ----------- | ----------- |
| segmentDebug (bool) | By default, tracking failure allows the form to continue
| segmentTrackEvent (string) | Can be a specified event or a formit variable to attribute to the event (required)
| segmentTrackFields (string) | Limit what is tracked to just the specified comma-separated fields. _Optionally translate fields to event properties using ==, e.g. `contact_name==name,contact_email==email`_
| segmentIdentifyFields (string) | Add identity fields from your form to a user in Segment. Works similarly to segmentTrackFields.

## Plugin

### SegmentTrackPlugin

Tracks a users login, logout, and profile save events

## System Settings

| Key | Description | Default |
| ----------- | ----------- | ----------- | 
| write_key | The API write key specified to your Segment source. | _null_ |
| use_modx_id | Track user using the MODX User ID if logged in and no tracking ID is specified in segmenttracker cookie. | true |
| prefix_modx_id | If tracking using the MODX User ID you can add a prefix to prevent conflicts with other systems. | _null_ |',
    'changelog' => 'Changelog for SegmentTracker

segmenttracker 1.0.0-beta1
==============
- Initial release.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '54d466439d6396fbc8c06c98aefdec8a',
      'native_key' => 'segmenttracker',
      'filename' => 'modNamespace/122f45ef9bf90c129db61b257522048e.vehicle',
      'namespace' => 'segmenttracker',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '928582d6bedc75feb2b5584adaf4e58c',
      'native_key' => 'segmenttracker.write_key',
      'filename' => 'modSystemSetting/c3c00f2f3a792922297c499620a5e3de.vehicle',
      'namespace' => 'segmenttracker',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb4ad0e67578ed4735f23443fde9b910',
      'native_key' => 'segmenttracker.prefix_modx_id',
      'filename' => 'modSystemSetting/f5fa001521023e5cbb912fbe163506c7.vehicle',
      'namespace' => 'segmenttracker',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e12dbc867ccdb2f5e8645adecf0e2b41',
      'native_key' => 'segmenttracker.use_modx_id',
      'filename' => 'modSystemSetting/6e16a5da4483b662b714f39c8e60c177.vehicle',
      'namespace' => 'segmenttracker',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2354a7848ad0c000dd2fa89bc182edfb',
      'native_key' => NULL,
      'filename' => 'modCategory/cb6ff9193626b11ec94d9bdec3ed9186.vehicle',
      'namespace' => 'segmenttracker',
    ),
  ),
);