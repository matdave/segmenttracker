<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Cal Henderson

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '# Segment Tracker for MODX

This package contains options for tracking MODX user interactions in Segment. To signup for Segment visit https://segment.com/. 

This package assumes you have the Segment javascript tracking code enabled on the frontend of your site. 

## Snippets

### SegmentTrack

Add this snippet to a page or call via runSnippet to add segment tracking to interactions.
 
#### Properties:
    
| Property | Description |
| ----------- | ----------- |
| event (string) | A specified event to track (required) | 
| properties (mixed) | Track additional field value pairs either as a passed array array(\'property1\'=>\'value1\'), a comma-separated string `property1==value1`, or json `{"property1":"value1"}`. | 
| identity (mixed) | Add identity field value pairs either as a passed array array(\'id\'=>\'modx_1\',\'name\'=>\'Full Name\'), a comma-separated string `id==modx_1,name==Full Name`, or json `{"id":"modx_1","name":"Full Name"}`. | 
### Segment.FormIt.Hook
 
  Add this hook to a FormIt call to track interactions
 
#### Properties:

| Property | Description |
| ----------- | ----------- |
| segmentDebug (bool) | By default, tracking failure allows the form to continue
| segmentTrackEvent (string) | Can be a specified event or a formit variable to attribute to the event (required)
| segmentTrackFields (string) | Limit what is tracked to just the specified comma-separated fields. _Optionally translate fields to event properties using ==, e.g. `contact_name==name,contact_email==email`_
| segmentIdentifyFields (string) | Add identity fields from your form to a user in Segment. Works similarly to segmentTrackFields.

## Plugin

### SegmentTrackPlugin

Tracks a users login, logout, and profile save events

## System Settings

| Key | Description | Default |
| ----------- | ----------- | ----------- | 
| write_key | The API write key specified to your Segment source. | _null_ |
| use_modx_id | Track user using the MODX User ID if logged in and no tracking ID is specified in segmenttracker cookie. | true |
| prefix_modx_id | If tracking using the MODX User ID you can add a prefix to prevent conflicts with other systems. | _null_ |',
    'changelog' => 'Changelog for SegmentTracker

segmenttracker 1.0.0-beta2
==============
- Fix issues with formit hook not tracking properties

segmenttracker 1.0.0-beta1
==============
- Initial release.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'fae39396af5dbbcc2a182543023bc53d',
      'native_key' => 'segmenttracker',
      'filename' => 'modNamespace/529a752af5815823f08ebc27b7e4877e.vehicle',
      'namespace' => 'segmenttracker',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce7e4b4927cfca616e4adae1c32eda59',
      'native_key' => 'segmenttracker.write_key',
      'filename' => 'modSystemSetting/a8325c2eeb1d00c1604b6b7ed7befc76.vehicle',
      'namespace' => 'segmenttracker',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a80456b7f20922fb69fba8b6246e1d3b',
      'native_key' => 'segmenttracker.prefix_modx_id',
      'filename' => 'modSystemSetting/438b8cb11a1e46aa2c1b49ab4c9ec80c.vehicle',
      'namespace' => 'segmenttracker',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e741b1a9301c7ada19dc872949e2a97',
      'native_key' => 'segmenttracker.use_modx_id',
      'filename' => 'modSystemSetting/10a373e0ab768f81134c737ad9804761.vehicle',
      'namespace' => 'segmenttracker',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '82f307ecd78d231e5bff65b15484663e',
      'native_key' => NULL,
      'filename' => 'modCategory/09f2713bdd22f852cb368404ce0aa555.vehicle',
      'namespace' => 'segmenttracker',
    ),
  ),
);