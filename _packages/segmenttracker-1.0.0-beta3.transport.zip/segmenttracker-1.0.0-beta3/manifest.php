<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2016 Cal Henderson

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '# Segment Tracker for MODX

This package contains options for tracking MODX user interactions in Segment. To signup for Segment visit https://segment.com/. 

This package assumes you have the Segment javascript tracking code enabled on the frontend of your site. 

## Snippets

### SegmentTrack

Add this snippet to a page or call via runSnippet to add segment tracking to interactions.
 
#### Properties:
    
| Property | Description |
| ----------- | ----------- |
| event (string) | A specified event to track (required) | 
| properties (mixed) | Track additional field value pairs either as a passed array array(\'property1\'=>\'value1\'), a comma-separated string `property1==value1`, or json `{"property1":"value1"}`. | 
| identity (mixed) | Add identity field value pairs either as a passed array array(\'id\'=>\'modx_1\',\'name\'=>\'Full Name\'), a comma-separated string `id==modx_1,name==Full Name`, or json `{"id":"modx_1","name":"Full Name"}`. | 
### Segment.FormIt.Hook
 
  Add this hook to a FormIt call to track interactions
 
#### Properties:

| Property | Description |
| ----------- | ----------- |
| segmentDebug (bool) | By default, tracking failure allows the form to continue
| segmentTrackEvent (string) | Can be a specified event or a formit variable to attribute to the event (required)
| segmentTrackFields (string) | Limit what is tracked to just the specified comma-separated fields. _Optionally translate fields to event properties using ==, e.g. `contact_name==name,contact_email==email`_
| segmentIdentifyFields (string) | Add identity fields from your form to a user in Segment. Works similarly to segmentTrackFields.

## Plugin

### SegmentTrackPlugin

Tracks a users login, logout, and profile save events

## System Settings

| Key | Description | Default |
| ----------- | ----------- | ----------- | 
| write_key | The API write key specified to your Segment source. | _null_ |
| use_modx_id | Track user using the MODX User ID if logged in and no tracking ID is specified in segmenttracker cookie. | true |
| prefix_modx_id | If tracking using the MODX User ID you can add a prefix to prevent conflicts with other systems. | _null_ |',
    'changelog' => 'Changelog for SegmentTracker

segmenttracker 1.0.0-beta3
==============
- Fix incorrect method called error

segmenttracker 1.0.0-beta2
==============
- Fix issues with formit hook not tracking properties

segmenttracker 1.0.0-beta1
==============
- Initial release.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '0465f1fc4580e16f60d27e95732d09b4',
      'native_key' => 'segmenttracker',
      'filename' => 'modNamespace/6727c14bef6d62be2ff18233f0b7d239.vehicle',
      'namespace' => 'segmenttracker',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '208b0a7f0aaaafa55b60b5e299d5fad6',
      'native_key' => 'segmenttracker.write_key',
      'filename' => 'modSystemSetting/1e3b0f7760a7a10c4e9e9a2dd32f4204.vehicle',
      'namespace' => 'segmenttracker',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'daa380e9b3839cb3433e14b6fccb4eb6',
      'native_key' => 'segmenttracker.prefix_modx_id',
      'filename' => 'modSystemSetting/a3292ad826b8265ac7507d89ad07b387.vehicle',
      'namespace' => 'segmenttracker',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66a3fb039dcc62e7bd1cab4d065feeec',
      'native_key' => 'segmenttracker.use_modx_id',
      'filename' => 'modSystemSetting/df65024e51b2e403ff0420c15793cb4a.vehicle',
      'namespace' => 'segmenttracker',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1b82547fb763cf3e75bc25e18c00b3a9',
      'native_key' => NULL,
      'filename' => 'modCategory/caef7d7a3d34f1c772e636bbd6df2d24.vehicle',
      'namespace' => 'segmenttracker',
    ),
  ),
);